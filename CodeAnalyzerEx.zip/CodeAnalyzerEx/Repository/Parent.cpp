#include "Parent.h"
#include "Child.h"

#ifdef TEST_PARENT
int main() {
	globalFunction1();
}
#endif