#ifndef CHILD2_H
#define CHILD2_H

using data = std::string;

namespace ChildTest2 {
	class Child {
		
	};
}

#endif