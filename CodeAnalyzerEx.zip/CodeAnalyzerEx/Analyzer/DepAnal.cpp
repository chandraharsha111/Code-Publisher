// DepAnal

#include "DepAnal.h"

#ifdef TEST_DEPANAL

//function to iterate through all files in repository by accepting command line arguments
inline std::unordered_map<std::string, std::vector<std::string>> TypeAnal::dependencyTable(int argc, char* argv[]) {
	std::vector<std::string> filecontainer;
	std::vector<std::string> currentFiles;
	std::string dirpath_ = argv[1];
	std::string openInBrowser = "..\\Repository\\index.html";
	std::vector<std::string> currentDirectories = directory.getDirectories(dirpath_);
	for (size_t i = 0; i < currentDirectories.size(); i++) {
		std::cout << currentDirectories[i] << "\n";
	}
	for (size_t i = 0; i < currentDirectories.size(); i++) {
		std::string appendpath = dirpath_ + "/" + currentDirectories[i];
		std::string temp = dirpath_ + "/" + currentDirectories[i] + "/";
		p.StylingPublisherCSS(temp);
		p.StylingPublisherJS(temp);
		std::vector<std::string> temporaryFiles = directory.getFiles(appendpath);
		for (size_t k = 0; k < temporaryFiles.size(); k++) {
			currentFiles.push_back(dirpath_ + "/" + currentDirectories[i] + "/" + temporaryFiles[k]);
		}
	}
	for (size_t temp = 0; temp < currentFiles.size(); temp++) {
		if ((path.getExt(currentFiles[temp]) == "h") || (path.getExt(currentFiles[temp]) == "cpp"))
			filecontainer.push_back(currentFiles[temp]);
	}
	//print the result 
	std::cout << "\n\n **************************printing  Dependency Table contents ***************************\n ";
	std::cout << "\n\n  List of files checked into Repository check\n\n";
	for (size_t t = 0; t < filecontainer.size(); t++) {
		std::cout << filecontainer[t] << "\n";
		std::string path = filecontainer[t];
		p.publishCode(path);
	}
	for (auto t : filecontainer) {
		std::string refTTString = t;
		dep.depResult = dep.DependencyAnalysistable(TT, refTTString);
	}
	std::string temp1 = openInBrowser;
	std::cout << "\n\n File to be opened in browser path -->" << temp1 << std::endl;
	std::wstring temp2 = std::wstring(temp1.begin(), temp1.end());
	LPCWSTR helpfile = (LPCWSTR)temp2.c_str();
	ShellExecute(NULL, L"open", helpfile, NULL, NULL, SW_SHOWNORMAL);
	return dep.depResult;
	}
int main(int argc, char* argv[])
{
	TypeAnal ta;
	ta.dependencyTable(argc, argv);
}
#endif
